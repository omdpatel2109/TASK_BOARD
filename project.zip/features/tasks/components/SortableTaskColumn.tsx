
// "use client";

// import { useDroppable } from "@dnd-kit/core";
// import { useSortable, SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
// import { CSS } from "@dnd-kit/utilities";
// import { GripVertical, EyeOff } from "lucide-react";
// import PriorityGroup from "./PriorityGroup";
// import TaskCard from "./TaskCard";
// import type { Task, TaskColumn, TaskPriority } from "@/features/tasks/type/taskType";
// import type { ReactNode } from "react";

// const getColumnDragId = (id: string | number) => `column-${id}`;

// const PRIORITY_GROUPS: { id: TaskPriority; label: string; dot: string }[] = [
//     {
//         id: "high",
//         label: "High Priority",
//         dot: "bg-red-500",
//     },
//     {
//         id: "medium",
//         label: "Medium Priority",
//         dot: "bg-amber-500",
//     },
//     {
//         id: "low",
//         label: "Low Priority",
//         dot: "bg-emerald-500",
//     },
// ];

// function DropZone({ id, children }: { id: string; children: ReactNode }) {
//     const { setNodeRef, isOver } = useDroppable({ id });

//     return (
//         <div
//             ref={setNodeRef}
//             className={`min-h-[500px] rounded-md ${
//                 isOver
//                     ? "bg-blue-50 ring-2 ring-blue-400 dark:bg-slate-700"
//                     : ""
//             }`}
//         >
//             {children}
//         </div>
//     );
// }

// interface SortableTaskColumnProps {
//     column: TaskColumn;
//     tasks: Task[];
//     isFilterApplied: boolean;
//     onEdit: (task: Task) => void;
//     onDelete: (id: string) => void;
//     onToggleVisibility: (columnId: string) => void;
// }

// // Render columns and their tasks.
// export default function SortableTaskColumn({
//     column,
//     tasks,
//     isFilterApplied,
//     onEdit,
//     onDelete,
//     onToggleVisibility,
// }: SortableTaskColumnProps) {
//     const {
//         attributes,
//         listeners,
//         setNodeRef,
//         transform,
//         transition,
//         isDragging,
//     } = useSortable({
//         id: getColumnDragId(column.id),
//         data: {
//             type: "column",
//             columnId: String(column.id),
//         },
//     });

//     const columnTasks = tasks
//         .filter((task) => String(task.status) === String(column.id))
//         .sort((a, b) => a.order - b.order);

//     return (
//         <div
//             ref={setNodeRef}
//             style={{
//                 transform: CSS.Transform.toString(transform),
//                 transition,
//                 opacity: isDragging ? 0.5 : 1,
//                 position: "relative",
//             }}
//             className="w-80 shrink-0 rounded-xl border border-gray-200 bg-gray-50 p-2 dark:border-slate-700 dark:bg-slate-800"
//         >
//             {/* Column Header */}
//             <div className="mx-3 mb-3 mt-1 flex items-center justify-between">
//                 <div className="flex min-w-0 items-center gap-2">
//                     <h3 className="truncate font-semibold text-gray-700 dark:text-primary-dark-text">
//                         {column.title}
//                     </h3>

//                     <span className="rounded-full bg-gray-200 px-2 py-1 text-xs font-medium text-gray-700 dark:bg-slate-700 dark:text-third-dark-text">
//                         {columnTasks.length}
//                     </span>
//                 </div>

//                 <div className="flex items-center gap-2">
//                     {columnTasks.length === 0 && (
//                         <button
//                             type="button"
//                             onPointerDown={(event) => event.stopPropagation()}
//                             onClick={() => onToggleVisibility(String(column.id))}
//                             className="rounded p-1 text-gray-400 hover:bg-gray-200 hover:text-gray-700 dark:hover:bg-slate-700 dark:hover:text-primary-dark-text"
//                         >
//                             <EyeOff className="h-4 w-4" />
//                         </button>
//                     )}

//                     <button
//                         type="button"
//                         {...attributes}
//                         {...listeners}
//                         className="cursor-grab rounded p-1 text-gray-400 hover:bg-gray-200 hover:text-gray-700 active:cursor-grabbing dark:hover:bg-slate-700 dark:hover:text-white"
//                     >
//                         <GripVertical className="h-5 w-5" />
//                     </button>
//                 </div>
//             </div>

//             {/* Column Task Area */}
//             <DropZone id={String(column.id)}>
//                 <div className="flex min-h-[500px] flex-col gap-2 py-1">

//                     {isFilterApplied ? (
//                         // Show normal task cards when a filter is active.
//                         <SortableContext
//                             items={columnTasks.map((task) => String(task.id))}
//                             strategy={verticalListSortingStrategy}
//                         >
//                             <div className="flex flex-col gap-3">
//                                 {columnTasks.map((task) => (
//                                     <TaskCard
//                                         key={task.id}
//                                         task={task}
//                                         onEdit={onEdit}
//                                         onDelete={onDelete}
//                                     />
//                                 ))}
//                             </div>
//                         </SortableContext>
//                     ) : (
//                         // Show priority groups when no filter is active.
//                         PRIORITY_GROUPS.map((group) => {
//                             const priorityTasks = columnTasks.filter(
//                                 (task) => task.priority === group.id
//                             );

//                             return (
//                                 <PriorityGroup
//                                     key={group.id}
//                                     columnId={String(column.id)}
//                                     priority={group.id}
//                                     label={group.label}
//                                     dot={group.dot}
//                                     tasks={priorityTasks}
//                                     onEdit={onEdit}
//                                     onDelete={onDelete}
//                                 />
//                             );
//                         })
//                     )}

//                 </div>
//             </DropZone>
//         </div>
//     );
// }

"use client";
import { useDroppable } from "@dnd-kit/core";
import {useSortable, SortableContext, verticalListSortingStrategy} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, EyeOff } from "lucide-react";
import PriorityGroup from "./PriorityGroup";
import TaskCard from "./TaskCard";
import type { Task, TaskColumn, TaskPriority} from "@/features/tasks/type/taskType";
import type { ReactNode } from "react";
const getColumnDragId = (id: string | number) => `column-${id}`;

const PRIORITY_GROUPS: {
    id: TaskPriority;
    label: string;
    dot: string;
}[] = [
    { id: "high", label: "High Priority", dot: "bg-red-500" },
    { id: "medium", label: "Medium Priority", dot: "bg-amber-500" },
    { id: "low", label: "Low Priority", dot: "bg-emerald-500" },
];

function DropZone({id, children}: {id: string; children: ReactNode}) {
    const { setNodeRef, isOver } = useDroppable({ id });
    return (
        <div ref={setNodeRef} className={`min-h-[500px] rounded-md ${
                isOver ? "bg-blue-50 ring-2 ring-blue-400 dark:bg-slate-700" : ""}`}>
            {children}
        </div>
    );
}

interface SortableTaskColumnProps {
    column: TaskColumn;
    tasks: Task[];
    isFilterApplied: boolean;
    onEdit: (task: Task) => void;
    onDelete: (id: string) => void;
    onToggleVisibility: (columnId: string) => void;
}

export default function SortableTaskColumn({ column, tasks, isFilterApplied, onEdit,
    onDelete, onToggleVisibility}: SortableTaskColumnProps) {
    const{attributes, listeners, setNodeRef, transform, transition, isDragging} = useSortable({
        id: getColumnDragId(column.id),
        data: {
            type: "column",
            columnId: String(column.id),
        }
    });

    const columnTasks = tasks.filter((task) => String(task.status) === String(column.id))
        .sort((a, b) => a.order - b.order);

    return (
        <div ref={setNodeRef}
            style={{
                transform: CSS.Transform.toString(transform),
                transition,
                opacity: isDragging ? 0.5 : 1,
                position: "relative",
            }} className="w-80 shrink-0 rounded-xl border border-gray-200 bg-gray-50 p-2 dark:border-slate-700 dark:bg-slate-800">
            <div className="mx-3 mb-3 mt-1 flex items-center justify-between">
                <div className="flex min-w-0 items-center gap-2">
                    <h3 className="truncate font-semibold text-gray-700 dark:text-primary-dark-text">
                        {column.title}
                    </h3>

                    <span className="rounded-full bg-gray-200 px-2 py-1 text-xs font-medium text-gray-700 dark:bg-slate-700 dark:text-third-dark-text">
                        {columnTasks.length}
                    </span>
                </div>

                <div className="flex items-center gap-2">
                    {columnTasks.length === 0 && (
                        <button type="button" onPointerDown={(event) =>
                                event.stopPropagation()}
                            onClick={() => onToggleVisibility(String(column.id))}
                            className="rounded p-1 text-gray-400 hover:bg-gray-200 hover:text-gray-700 dark:hover:bg-slate-700 dark:hover:text-primary-dark-text">
                            <EyeOff className="h-4 w-4" />
                        </button>
                    )}

                    <button type="button" {...attributes} {...listeners}
                        className="cursor-grab rounded p-1 text-gray-400 hover:bg-gray-200 hover:text-gray-700 active:cursor-grabbing dark:hover:bg-slate-700 dark:hover:text-white">
                        <GripVertical className="h-5 w-5" />
                    </button>
                </div>
            </div>

            <DropZone id={String(column.id)}>
                <div className="flex min-h-[500px] flex-col gap-2 py-1">
                    {isFilterApplied ? (
                        <SortableContext
                            items={columnTasks.map((task) => String(task.id))}
                            strategy={verticalListSortingStrategy}>
                            <div className="flex flex-col gap-3">
                                {columnTasks.map((task) => (
                                    <TaskCard key={task.id} task={task}
                                        isCompleted={Boolean(column.isCompleted)}
                                        onEdit={onEdit}
                                        onDelete={onDelete}/>
                                ))}
                            </div>
                        </SortableContext>
                    ) : (
                        PRIORITY_GROUPS.map((group) => {
                            const priorityTasks = columnTasks.filter(
                                (task) => task.priority === group.id
                            );

                            return (
                                <PriorityGroup key={group.id}
                                    columnId={String(column.id)}
                                    priority={group.id}
                                    label={group.label}
                                    dot={group.dot}
                                    tasks={priorityTasks}
                                    onEdit={onEdit}
                                    onDelete={onDelete}
                                    isCompleted={Boolean(column.isCompleted)}/>
                            );
                        })
                    )}
                </div>
            </DropZone>
        </div>
    );
}
